#' @useDynLib ExcursionSets, .registration = TRUE
#' @importFrom Rcpp sourceCpp



#' @title Constructs a `random.field` object, which represents a spatial or spatio-temporal random field defined over a grid.
#'
#' @param values A matrix, vector, or array containing the field values. If `grid` is `NULL`, `values` should be a matrix (or vector).
#' @param grid A matrix or data frame representing the coordinates of the grid points. Each column corresponds to a spatial dimension.
#'             If `NULL`, the grid will be automatically generated based on the dimensions of `values`.
#'
#' @return A `random.field` object containing:
#'   \item{values}{A vector of field values in the order of the provided or generated grid.}
#'   \item{dimensions}{An integer vector giving the number of unique points in each dimension of the grid.}
#'   \item{deltas}{A numeric vector giving the grid spacing for each dimension.}
#'   \item{grid}{A matrix or data frame representing the coordinates of the grid points.}
#'
#' @details
#' The `random.field` function is used to create a structured representation of a random field, which can be spatial or spatio-temporal in nature.
#' If `grid` is not specified, a default grid is generated based on the dimensions of `values`. The function also checks that the length of
#' `values` matches the number of rows in `grid`, ensuring consistency between the field values and the grid.
#'
#' @examples
#' # Create a random field with a generated grid
#' field <- random.field(matrix(rnorm(100), 10, 10))
#'
#' # Create a random field with a custom grid
#' grid <- expand.grid(x = seq(0, 1, length.out = 10), y = seq(0, 1, length.out = 10))
#' values <- rnorm(100)
#' field <- random.field(values, grid)
#'
#' @export
random.field <- function(values, grid = NULL) {
  if(is.null(grid)){
    values = as.matrix(values)
    if(ncol(values) == 1){
      grid = expand.grid(1:nrow(values))
    } else {
      grid = expand.grid(1:nrow(values), 1:ncol(values))
    }
  }
  dimensions = rep(NA, ncol(grid))
  deltas = rep(NA, ncol(grid))
  for(idx in 1:ncol(grid)){
    x = sort(unique(grid[,idx]))
    dimensions[idx] = length(x)
    if (dimensions[idx] > 1) deltas[idx] = x[2] - x[1]
  }
  values = as.vector(values)
  stopifnot(length(values) == nrow(grid))
  structure(
    list(
      values = values,         # Field values
      dimensions = dimensions, # Dimensionality of the random field
      deltas = deltas,         # Grid spacing for each dimension
      grid = grid              # Grid on which the field is defined
    ),
    class = "random.field"      # Assign the class "random.field"
  )
}


#' Checks if an object is of class `random.field`.
#'
#' @param obj An object to check.
#'
#' @return A logical value: `TRUE` if `obj` inherits the class `random.field`, otherwise `FALSE`.
#'
#' @export
is.random.field = function(obj) {
  return(inherits(obj, "random.field"))
}


#' Computes the area of the excursion set for a given threshold in a `random.field` object or matrix.
#'
#' @param rf A `random.field` object or a matrix. If `rf` is a matrix, it is treated as field values on a grid with spacing 1.
#' @param thresh A numeric threshold. Values greater than `thresh` are included in the excursion set.
#' @param mask a boolean vector of the same length as `rf$values` indicating whether or not the sites should be included in the area count.
#'
#' @return A numeric value representing the area of the excursion set, calculated as the sum of grid cell areas where values exceed `thresh`.
#'         If `rf` is a `random.field`, grid spacing (`deltas`) is used to compute the area.
#'
#' @export
excursionArea = function(rf, thresh = 0.5, mask = NULL){
  if (is.null(mask)) mask = 1
  if(is.random.field(rf)) return(sum((rf$values > thresh) * mask) * rf$deltas[1] * rf$deltas[2])
  rf = as.matrix(rf)
  if (length(mask) == length(rf)){
    dim(mask) = dim(rf)
  }
  return(sum((rf > thresh)*mask))
}


#' Computes the perimeter of the excursion set for a given threshold in a `random.field` object or matrix.
#'
#' @param rf A `random.field` object or a matrix. If `rf` is a matrix, it is converted to a `random.field`.
#' @param thresh A numeric threshold. Values greater than `thresh` are included in the excursion set.
#' @param incl_boundary A logical value. If `TRUE`, counts excursion set values along the boundary as part of the perimeter.
#' @param mask a boolean vector of the same length as `rf$values` indicating whether or not the sites should be included in the perimeter count.
#'
#' @return A numeric value representing the perimeter of the excursion set, calculated based on the grid spacing (`deltas`).
#'
#' @export
excursionPerimeter = function(rf, thresh = 0.5, incl_boundary = FALSE, mask = NULL){
  if(!is.random.field(rf)){
    rf = random.field(as.matrix(rf))
  }
  bf = rf$values > thresh
  dim(bf) = rf$dimensions

  if(is.null(mask)){
    per = .Call("_ExcursionSets_cpp_perimeter_bierme", bf, rf$deltas[1], rf$deltas[2])
    if (!incl_boundary){
      return(per)
    }
    border_count = sum(c(bf[1,], bf[,1], bf[nrow(bf),], bf[,ncol(bf)]))
    return(per+border_count)
  } else {
    dim(mask) = dim(bf)
    per_mask = .Call("_ExcursionSets_cpp_perimeter_bierme", mask, rf$deltas[1], rf$deltas[2])
    masked_black = masked_white = bf
    masked_black[which(!mask)] = 1
    per_black = .Call("_ExcursionSets_cpp_perimeter_bierme", masked_black, rf$deltas[1], rf$deltas[2])
    masked_white[which(!mask)] = 0
    per_white = .Call("_ExcursionSets_cpp_perimeter_bierme", masked_white, rf$deltas[1], rf$deltas[2])
    if(incl_boundary){
      return(per_white)
    } else {
      return((per_white + per_black - per_mask)/2)
    }
  }
}



#' Summarizes the connected components of an excursion set in a `random.field` object or binary matrix.
#'
#' @param rf A `random.field` object or a matrix. If `rf` is a matrix, it is converted to a `random.field`.
#' @param thresh A numeric threshold. Values in `rf` greater than `thresh` are included in the excursion set.
#' @param connectivity An integer specifying the connectivity type:
#'   - 8: Components connected by corners are considered connected.
#'   - 6: Components connected by corners are connected probabilistically.
#'   - 4 (or other values): Components connected only by edges.
#' @param incl_perim A logical value indicating whether to compute the perimeter of each component.
#'   The perimeter excludes the boundary in all cases.
#' @param incl_area A logical value indicating whether to compute the area of each component.
#' @param mask a boolean vector of the same length as `rf$values` indicating whether or not the sites should be included in the excursion set.
#'
#' @return A list summarizing the connected components, with the following elements:
#'   \item{ncc}{The number of connected components.}
#'   \item{nholes}{The number of holes in the connected components.}
#'   \item{euler}{The Euler characteristic, computed as \code{ncc - nholes}.}
#'   \item{labeled}{A `random.field` object labeling the connected components.}
#'   \item{holes_labeled}{A `random.field` object labeling the holes in the components.}
#'   \item{table}{A data frame where each row corresponds to a connected component, with columns:
#'     \itemize{
#'       \item \code{label}: The component's unique label.
#'       \item \code{area} (optional): The area of the component, if \code{incl_area = TRUE}.
#'       \item \code{perim} (optional): The perimeter of the component, if \code{incl_perim = TRUE}.
#'       \item \code{border}: Logical, indicating if the component touches the border of the field.
#'     }
#'   }
#'
#' @export
excursionComponents <- function(rf, thresh = 0.5, connectivity = 6, incl_perim = TRUE, incl_area = TRUE, mask = NULL){
  if(!is.random.field(rf)){
    rf = random.field(as.matrix(rf))
  }
  bf = rf$values > thresh
  dim(bf) = rf$dimensions
  if (!is.null(mask)){
    dim(mask) = dim(bf)
    bf = bf * mask
  }

  cc = .Call("_ExcursionSets_cpp_connected_components", bf, connectivity)
  labels = setdiff(cc$cc, 0)
  ncc = length(labels)
  hole_labels = setdiff(cc$ch, 0)
  nholes = length(hole_labels)
  euler = ncc - nholes
  m = ncol(bf)
  n = nrow(bf)

  tab = data.frame("label" = labels)
  if (incl_area){
    area_from_label = function(label){
      component = random.field(cc$cc == label, rf$grid)
      return(excursionArea(component, mask = mask))
    }
    areas = sapply(labels, area_from_label)
    tab = cbind(tab, "area" = areas)
  }
  if (incl_perim){
    perimeter_from_label = function(label){
      component = random.field(cc$cc == label, rf$grid)
      return(excursionPerimeter(component, mask = mask))
    }
    perims = sapply(labels, perimeter_from_label)
    tab = cbind(tab, "perim" = perims)
  }
  on_border = labels %in% c(cc$cc[1,], cc$cc[,1], cc$cc[nrow(cc$cc),], cc$cc[,ncol(cc$cc)])
  tab = cbind(tab, "border" = on_border)
  summary = list("ncc" = ncc,
                 "nholes" = nholes,
                 "euler" = euler,
                 "labeled" = random.field(cc$cc, rf$grid),
                 "holes_labeled" = random.field(cc$ch, rf$grid),
                 "table" = tab)
  return(summary)
}


#' Computes the full perimeter of the excursion set in a `random.field` object for a specified threshold, with an option to include the boundary.
#'
#' @param rf A `random.field` object representing the field values on a grid.
#' @param thresh A numeric threshold value. Values in `rf` greater than `thresh` are included in the excursion set.
#' @param incl_boundary A logical value indicating whether to include the perimeter along the boundary of the field.
#'
#' @return A numeric value representing the perimeter estimate of the excursion set. The perimeter is scaled by the grid spacing, `rf$deltas[1]`.
#'
#' @export
levelSetLength = function(rf, thresh, incl_boundary = FALSE){
  stopifnot(rf$deltas[1] == rf$deltas[2])
  stopifnot(is.random.field(rf))
  f = rf$values
  dim(f) = rf$dimensions

  per = .Call("_ExcursionSets_cpp_perimeter_unbiased", f, thresh)
  if (!incl_boundary){
    return(per * rf$deltas[1])
  }
  bf = as.matrix(f > thresh)
  border_count = sum(c(bf[1,], bf[,1], bf[nrow(bf),], bf[,ncol(bf)]))
  return((per + border_count) * rf$deltas[1])
}


#' Computes the radius of the smallest ball centered at a specified point that encloses an entire connected component of an excursion set in a two-dimensional `random.field`.
#'
#' @param rf A two-dimensional `random.field` object.
#' @param thresh A numeric threshold used to define the excursion set.
#' @param x0 A numeric vector specifying the center of the ball. Must be a row in `rf$grid` and part of the excursion set. Defaults to `c(0, 0)`.
#' @param finite Boolean. If FALSE, a value of `Inf` is returned if the connected component touches the b 
#'
#' @return A numeric value representing the radius of the smallest ball centered at `x0` that contains the connected excursion component containing `x0`.
#'
#' @export
upperExtremalRange = function(rf, thresh = 0.5, x0 = c(0, 0), finite = FALSE){
  x0 = as.numeric(x0)
  if(!is.random.field(rf)){
    rf = random.field(as.matrix(rf))
  }
  res = excursionComponents(rf, thresh, connectivity = 4, incl_perim = FALSE)

  origin_ind = which(abs(rf$grid[,1] - x0[1]) < 1e-12 & abs(rf$grid[,2] - x0[2]) < 1e-12)
  stopifnot(length(origin_ind) == 1)
  label = res$labeled$values[origin_ind]

  if(!finite){
    # Test to see if the CC touches the border
    ind = which(res$table$label == label)
    if (res$table$border[ind] ){
      return(Inf)
    }
  }

  inds = which(res$labeled$values == label)
  len = function(vec){
    return(norm(vec, type = "2"))
  }
  rf$grid[,1] = rf$grid[,1] - x0[1]
  rf$grid[,2] = rf$grid[,2] - x0[2]
  distances = apply(as.matrix(rf$grid[inds,]), MARGIN = 1, len)
  return(max(distances))
}


#' Generate Covariance Function Based on Specified Model
#'
#' This function returns a covariance function corresponding to the chosen model type.
#' Supported models include Gaussian, Exponential, and Matérn. The function produces a
#' closure that computes the covariance given a distance input, allowing for flexible
#' spatial or temporal modeling.
#'
#' @param model A character string specifying the type of covariance model.
#'     Must be one of ""Gauss"" (Gaussian), ""Exp"" (Exponential), or ""Matern"" (Matérn).
#' @param range A numeric value defining the range parameter for the covariance function.
#'     Defaults to "1". This parameter scales the distance in the covariance calculation.
#' @param nu A numeric value specifying the smoothness parameter for the Matérn covariance function.
#'     Defaults to "1.5". This parameter is relevant only if "model" is set to ""Matern"".
#'
#' @return A function that computes the covariance value for a given distance.
#'     The returned function accepts a numeric distance "h" and returns the corresponding covariance value.
#' @export
cov.model = function(model, range = 1, nu = 1.5){
  if (model == "Gauss"){
    cov_fun = function(h){
      h = h/range
      return(exp(-h^2 / 2))
    }
  } else if (model == "Exp"){
    cov_fun = function(h){
      h = h/range
      return(exp(-h))
    }
  } else if (model == "Matern"){
    cov_fun = function(h){
      res = h*0 + 1
      change = which(h > 0)
      h = h/range
      res[change] = (2^(1-nu)) / gamma(nu) * (sqrt(2 * nu) * h[change])^nu * besselK(sqrt(2 * nu) * h[change], nu)
      return(res)
    }
  } else {
    stop("Unknown model type. Please choose 'Gauss', 'Exp', or 'Matern'.")
  }
  if (model != "Matern") nu = NA
  return(structure(
    cov_fun,
    model = model,
    range = range,
    nu = nu
  ))
}


#' Creates a generator for simulating independent replicates of a Gaussian random field (GRF) on a specified spatial grid, using a given covariance function and optional conditioning sites.
#'
#' @param grid A matrix or data frame specifying the spatial grid of sites for the random field, where each row represents a site.
#' @param cov_fun A covariance function generated by `covModel`, defining the spatial correlation structure of the GRF.
#' @param method A character string indicating the decomposition method to use for generating the random field. Options are `"chol"` for Cholesky decomposition or `"eig"` for eigenvalue decomposition. Default is `"eig"`.
#' @param cond_sites An optional data frame or matrix with two columns representing the x- and y-coordinates of conditioning sites. If provided, the GRF is conditioned on values at these sites.
#'
#' @return A list containing the following elements for efficient GRF generation:
#'   \itemize{
#'     \item \code{L}: The decomposed covariance matrix for generating GRF replicates.
#'     \item \code{grid}: The spatial grid information.
#'     \item \code{cond_sites}: Conditioning sites if provided.
#'     \item \code{reg_coeff}: Regression coefficients used in conditioning.
#'     \item \code{cov_fun}: The covariance function specifying the spatial structure.
#'   }
#'
#' @examples
#' grid <- expand.grid(x = seq(0, 1, length.out = 10), y = seq(0, 1, length.out = 10))
#' cov_fun <- cov.model("Exp")
#' generator <- random.field.generator(grid, cov_fun)
#'
#' @export
random.field.generator = function(grid, cov_fun, cond_sites = NULL, method = "eig"){
  if (!is.null(cond_sites)){
    method = "eig"
    cond_sites = data.frame(cond_sites)
    names(cond_sites) = names(grid)
    new_grid = rbind(grid, cond_sites)
  } else {
    new_grid = grid
  }
  dist_matrix <- as.matrix(dist(new_grid))
  cov_matrix <- cov_fun(dist_matrix)
  if (!is.null(cond_sites)){
    q = nrow(grid)
    N = nrow(cov_matrix)
    Sigma11 = cov_matrix[1:q, 1:q]
    Sigma21 = cov_matrix[(q+1):N, 1:q]
    Sigma12 = cov_matrix[1:q, (q+1):N]
    Sigma22 = cov_matrix[(q+1):N, (q+1):N]
    reg_coeff = Sigma12 %*% solve(Sigma22)
    cov_matrix = Sigma11 - reg_coeff %*% Sigma21
  } else {
    reg_coeff = NULL
  }
  if (method == "chol"){
    requireNamespace("Matrix")
    cov_matrix <- as.matrix(Matrix::nearPD(cov_matrix)$mat)
    L <- chol(cov_matrix)  # Cholesky decomposition
  } else if (method == "eig"){
    eig <- eigen(cov_matrix)
    # Ensure non-negative eigenvalues
    eig$values[eig$values < 0] = 0
    L = eig$vectors %*% diag(sqrt(eig$values))
  } else {
    stop('randomFieldGenerator: Please select either "chol" or "eig" as the method.')
  }
  return(list("L" = L,
             "grid" = grid,
             "cond_sites" = cond_sites,
             "reg_coeff" = reg_coeff,
             "cov_fun" = cov_fun
  ))
}


#' Generates a realization of a Gaussian random field (GRF) using a generator object created by `random.field.generator`. The generator provides essential components, such as the spatial grid, covariance structure, and optional conditioning values, allowing for efficient field simulation.
#'
#' @param generator A generator object created by `random.field.generator`, containing the spatial grid, covariance matrix decomposition, and optional conditioning structure.
#' @param cond_val An optional numeric vector for values at the conditioning sites. This must match the number of conditioning sites specified in `generator$cond_sites`. If the generator includes conditioning, this argument is required.
#' @param exceedance Logical. If `TRUE`, ensures the generated field exceeds `cond_val` at conditioning sites when only one conditioning site is specified.
#'
#' @return A `random.field` object with values generated according to the specified covariance structure, spatial grid, and conditioning values if provided.
#'
#' @examples
#' grid <- expand.grid(x = seq(0, 1, length.out = 10), y = seq(0, 1, length.out = 10))
#' cov_fun <- cov.model("Exp")
#' generator <- random.field.generator(grid, cov_fun)
#' field <- generateGaussian(generator)
#'
#' @export
generateGaussian = function(generator, cond_val = NULL, exceedance = FALSE){
  if(!is.null(cond_val) & exceedance){
    stopifnot(nrow(generator$cond_sites) == 1)
    while(TRUE){
      Z = rnorm(1)
      if (Z > cond_val){
        cond_val = Z
        break
      }
    }
  }
  Z <- rnorm(ncol(generator$L))  # Generate independent standard normal variables
  if (!is.null(generator$cond_sites)){
    if (is.null(cond_val)){
      if(nrow(generator$cond_sites) == 1){
        cond_val = rnorm(1)
      } else {
        stop("generateRF: Please provide values for the conditioning sites.")
      }
    }
    mu = generator$reg_coeff %*% cond_val
  } else {
    mu = 0
  }
  values <- as.vector(generator$L %*% Z + mu) # Generate the GRF
  return(random.field(values, generator$grid))
}


#' Generates a realization of a Student's t-distributed random field based on a Gaussian random field (GRF) generator. The degrees of freedom and optional thresholding allow for simulating fields with heavier tails than Gaussian fields.
#'
#' @param generator A generator object created by `random.field.generator`, providing the spatial grid, covariance structure, and any optional conditioning values.
#' @param k Degrees of freedom for the Student's t-distribution.
#' @param thresh Optional numeric value setting a threshold; the generated field exceeds this threshold at conditioning sites if conditioning is applied.
#'
#' @return A `random.field` object containing values sampled from a Student's t-distributed random field over the spatial grid specified by the generator.
#'
#' @export
generateStudent = function(generator, k, thresh = NULL){
  Z = NULL
  if(!is.null(generator$cond_sites)){
    stopifnot(nrow(generator$cond_sites) == 1)
    Z = rnorm(k+1)
    while(!is.null(thresh)){
      Z = rnorm(k+1)
      student = Z[1] / sqrt(sum(Z[-1]^2)/k)
      if (student > thresh){
        break
      }
    }
  }
  G = c()
  for (idx in 1:(k+1)){
    G = cbind(G, generateGaussian(generator, Z[idx])$values)
  }
  student = G[,1] / sqrt(apply(G[,-1]^2, MARGIN = 1, sum) / k)
  return(random.field(student, generator$grid))
}


#' Generates a realization of a chi-squared random field based on a Gaussian random field (GRF) generator. The degrees of freedom and optional thresholding allow for simulating fields with chi-squared distributed values.
#'
#' @param generator A generator object created by `random.field.generator`, which includes the spatial grid, covariance structure, and any optional conditioning.
#' @param k Degrees of freedom for the chi-squared distribution.
#' @param thresh Optional numeric value setting a threshold; the generated field exceeds this threshold at conditioning sites if conditioning is applied.
#'
#' @return A `random.field` object containing values sampled from a chi-squared random field across the spatial grid defined in the generator.
#'
#' @export
generateChisq = function(generator, k, thresh = NULL){
  Z = NULL
  if(!is.null(generator$cond_sites)){
    stopifnot(nrow(generator$cond_sites) == 1)
    Z = rnorm(k)
    while(!is.null(thresh)){
      Z = rnorm(k)
      chisq = sum(Z^2)
      if (chisq > thresh){
        break
      }
    }
  }
  G = c()
  for (idx in 1:k){
    G = cbind(G, generateGaussian(generator, Z[idx])$values)
  }
  chisq = apply(G^2, MARGIN = 1, sum)
  return(random.field(chisq, generator$grid))
}


#' Generates a realization of a random field based on a Gaussian random field (GRF) generator, with values scaled by a random factor sampled from a Pareto distribution. This creates a random field with a specified mixture of Gaussian and heavy-tailed behavior.
#'
#' @param generator A generator object created by `random.field.generator`, specifying the spatial grid, covariance structure, and any optional conditioning values.
#' @param alpha Numeric, the shape parameter for the Pareto distribution, which influences the tail heaviness of the mixture.
#' @param thresh Optional numeric value setting a threshold; the generated field exceeds this threshold at conditioning sites if conditioning is applied.
#'
#' @return A `random.field` object containing values from a heavy-tailed random field across the spatial grid as defined by the generator.
#'
#' @export
generateMixture = function(generator, alpha, thresh = NULL){
  Z = NULL
  Lambda = runif(1)^(-alpha)
  if(!is.null(generator$cond_sites)){
    stopifnot(nrow(generator$cond_sites) == 1)
    Z = rnorm(1)
    while(!is.null(thresh)){
      Z = rnorm(1)
      Lambda = runif(1)^(-alpha)
      if (Z * Lambda > thresh){
        break
      }
    }
  }
  gauss = generateGaussian(generator, Z)
  gauss$values = gauss$values * Lambda
  return(gauss)
}



#' Plot a Random Field and its Excursion Sets
#'
#' This function generates an image plot of a random field (RF) object, optionally displaying the excursion set where the field exceeds a given threshold. If a threshold is provided, the excursion set is shown in grayscale, with areas exceeding the threshold highlighted. If no threshold is given, the entire random field is plotted with contour lines.
#'
#' @param rf A random field object containing spatial data to be visualized.
#' @param thresh Optional numeric threshold value. If provided, the plot will display the excursion set, which includes regions where the random field values exceed this threshold. When `thresh` is not provided, the function displays the full field with contour lines.
#'
#' @return An image plot displaying the excursion set in grayscale if a threshold is specified, or a complete image with contours if not.
#'
#' @export
plotRandomField = function(rf, thresh = NULL){
  if(!is.random.field(rf)){
    rf = random.field(as.matrix(rf))
  }
  z = rf$values
  dim(z) = rf$dimensions
  x = unique(rf$grid[,1])
  y = unique(rf$grid[,2])
  if (is.null(thresh)){
    image(x, y, z)
    contour(x, y, z, add = TRUE)
  } else {
    image(x, y, z > thresh, col=gray.colors(2,start=1,end=0.5))
  }
}


#' Compute Extent Profile of an Excursion Set
#'
#' This function calculates the proportion of the area within a circular region (ball) centered at a specified point \eqn{x_0} that is covered by the excursion set of a given random field. The excursion set consists of regions where the field values exceed a specified threshold. The function computes this proportion for distances from the center up to a maximum radius, returning the coverage ratios at each available distance.
#'
#' @param rf A `random.field` object representing the spatial random field to analyze.
#' @param thresh A numeric threshold value. Regions where the field values exceed this threshold are included in the excursion set.
#' @param max_dist The maximum radius (distance) from `x0` within which to compute the coverage ratios. Smaller values of `max_dist` can speed up computation by limiting the extent of the profile.
#' @param x0 A numeric vector specifying the coordinates of the center point for the profile. This should be in the format \eqn{c(x, y)} and must lie within the grid of `rf`.
#'
#' @return A data frame with columns:
#'   - `x`: Distances from `x0` for which the area ratios are computed (up to `max_dist`).
#'   - `y`: Proportion of the area within each ball (at the corresponding distance in `x`) that is part of the excursion set.
#'
#' @export
extent.profile = function(rf, thresh = 0.5, max_dist = Inf, x0 = c(0,0)){
  x0 = as.numeric(x0)
  get_representatives = function(vec){
    vec = sort(vec)
    N = length(vec)
    is_representative = rep(FALSE, N)
    for (i in N:1){
      current = vec[i]
      if (i == N){
        is_representative[i] = TRUE
      } else {
        if (current + 1e-12 < prev){
          is_representative[i] = TRUE
        }
      }
      prev = current
    }
    inds_representatives = which(is_representative)
    representatives = vec[inds_representatives]
    return(list("reps" = representatives,
                "counts" = inds_representatives))
  }

  len = function(vec){
    return(norm(vec, type = "2"))
  }

  rf$grid[,1] = rf$grid[,1] - x0[1]
  rf$grid[,2] = rf$grid[,2] - x0[2]
  distances = apply(as.matrix(rf$grid), MARGIN = 1, len)
  keep_only = which(distances <= max_dist)
  distances = distances[keep_only]
  values = rf$values[keep_only]
  representatives_all = get_representatives(distances)

  inds_exceedances = which(values > thresh)
  distances_to_exceedances = distances[inds_exceedances]
  representatives_exceedances = get_representatives(distances_to_exceedances)

  N = length(representatives_all$reps)
  inds = rep(NA, N)
  for (i in N:1){
    M = length(representatives_exceedances$reps)
    current = representatives_all$reps[i]
    while (representatives_exceedances$reps[M] > current + 1e-12){
      M = M - 1
    }
    inds[i] = M
  }
  ratios = representatives_exceedances$counts[inds] / representatives_all$counts
  return(data.frame("x" = representatives_all$reps, "y" = ratios))
}


#' Extract the Tail Dependence Function from an `extent.profile`
#'
#' This function computes a tail dependence coefficient function based on an extent profile. The extent profile, typically an average of several realizations, provides coverage proportions for regions at varying distances from a central point, \eqn{x_0}, relative to a threshold exceedance. This tail dependence coefficient quantifies the empirical probability that a point at a specified distance \eqn{new\_x} from \eqn{x_0} exceeds the threshold, given that \eqn{x_0} itself is in the exceedance region.
#'
#' @param ep The extent profile (see `extent.profile` documentation for details), representing the proportion of areas within circular regions centered at \eqn{x_0} that exceed the threshold.
#' @param new_x Numeric vector of distances at which to compute the tail dependence coefficients. If `NULL`, computations are based on all available distances in `ep`.
#'
#' @return A list with the following elements:
#'   - `x`: The distances at which the tail dependence coefficients were computed.
#'   - `y`: The computed values of the tail dependence coefficient at each distance in `x`.
#'   - `slope_at_0`: The slope of the tail dependence function at \eqn{x = 0}, providing an indication of the initial rate of dependence decay.
#'
#' @export
exceedanceProbabilities = function(ep, new_x = NULL){
  if (is.null(new_x)){
    new_x = ep$x
  }
  # Fit a spline
  spline_fit <- smooth.spline(ep$x, ep$y,
                              spar = 0.95,
                              w = c(1e10, rep(1, length(ep$x)-1)))

  # plot(ep)
  # lines(spline_fit)
  new_y = predict(spline_fit, new_x)$y + new_x/2*predict(spline_fit, new_x, deriv = 1)$y
  slope_at_0 = 3/2*predict(spline_fit, 0, deriv = 1)$y
  res = list("x" = new_x,
             "y" = new_y,
             "slope_at_0" = slope_at_0)
  return(res)
}


#' Estimate the Density of Non-Negative Observations at Zero
#'
#' This function estimates the density of a set of non-negative observations at zero by calculating the slope of the estimated probability density function (PDF) near zero. It provides an approximation for the density height at zero based on the empirical cumulative distribution function (ECDF) of the observations.
#'
#' @param x Numeric vector of non-negative observations for which the density at zero is to be estimated.
#'
#' @return Numeric value representing the estimated density (slope of the PDF) at zero.
#'
#' @details The function removes any non-finite values from `x`, setting them to the maximum finite value in the vector. It then constructs the ECDF of `x` and fits a smoothing spline to estimate the PDF slope at zero. This method is particularly useful for data with a mass at or near zero.
#'
#' @export
densityAtZero = function(x){
  bad_inds = which(!is.finite(x))
  if (length(bad_inds) > 0) x[bad_inds] = max(x[-bad_inds])
  f = ecdf(x)
  # plot(f, xlim = c(0,max(x)))
  xy = cbind(x, f(x))
  if (length(bad_inds) > 0) xy = xy[-bad_inds,]
  xy = rbind(c(0,0), xy)
  # Fit a spline
  spline_fit <- smooth.spline(xy[,1], xy[,2],
                              spar = 0.99,
                              w = c(1e10, rep(1, nrow(xy)-1)))
  # lines(predict(spline_fit, sort(xy[,1])))
  return(predict(spline_fit, 0, deriv = 1)$y)
}
